print("welcome to tip calculator")
total=float(input("what was the total bill?"))
tip=int(input("how much tip do you like to give? 10,12,15?"))
people = int(input("how many pepole to split the bill?"))
bill_with_tip=float(tip/100*total+total)
bill_with_people=bill_with_tip/people
split_bill=round(bill_with_people,2)
print(f"each person has to pay {split_bill}")
